package by.it_academy.jd2._107;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}