package by.it_academy.jd2._107.service.api;

import by.it_academy.jd2._107.dto.VoteDTO;

public interface IVoteService {

    public void create(VoteDTO vote);
}
